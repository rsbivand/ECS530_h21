
## ----set-options-cdn, echo=TRUE, results='hide'--------------------------------------------
td <- tempfile()
dir.create(td)
Sys.setenv("PROJ_USER_WRITABLE_DIRECTORY"=td)
#Sys.setenv("PROJ_NETWORK"="ON")
options("rgdal_show_exportToProj4_warnings"="none")


## ---- echo=TRUE----------------------------------------------------------------------------
needed <- c("ggplot2", "mapsf", "colorspace", "RColorBrewer", "classInt", 
 "tmap", "rgdal", "mapview", "sp", "RSQLite", "sf")


## ------------------------------------------------------------------------------------------
library(sf)
#library(rgdal)
sf_extSoftVersion()
head(sf_proj_info("ellps"))


## ------------------------------------------------------------------------------------------
data("GridsDatums", package="rgdal")
GridsDatums[grep("Norway", GridsDatums$country),]


## ---- echo = TRUE--------------------------------------------------------------------------
library(RSQLite)
(DB0 <- sf_proj_search_paths())
DB <- file.path(DB0[length(DB0)], "proj.db")
db <- dbConnect(SQLite(), dbname=DB)
cat(strwrap(paste(dbListTables(db), collapse=", ")), sep="\n")


## ------------------------------------------------------------------------------------------
PROJ.DB <- dbReadTable(db, "crs_view")
dbDisconnect(db)
PROJ.DB[grep("Norway", PROJ.DB$name), 2:5]


## ------------------------------------------------------------------------------------------
PROJ.DB[grep("Oslo", PROJ.DB$name), 2:5]


## ------------------------------------------------------------------------------------------
st_crs("EPSG:25831")


## ------------------------------------------------------------------------------------------
getClassDef("CRS", package="sp")


## ------------------------------------------------------------------------------------------
st_crs(4326)


## ---- echo = TRUE--------------------------------------------------------------------------
ellps <- sf_proj_info("ellps")
(clrk66 <- unlist(ellps[ellps$name=="clrk66",]))


## ---- echo = TRUE--------------------------------------------------------------------------
eval(parse(text=clrk66["major"]))
eval(parse(text=clrk66["ell"]))
print(sqrt((a^2-b^2)/a^2), digits=10)


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
bp_file <- system.file("gpkg/b_pump.gpkg", package="sf")
b_pump_sf <- st_read(bp_file)


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
proj5 <- paste0("+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717",
 " +x_0=400000 +y_0=-100000 +datum=OSGB36 +units=m +no_defs")
legacy <- st_crs(proj5)
proj6 <- legacy$proj4string
proj5_parts <- unlist(strsplit(proj5, " "))
proj6_parts <- unlist(strsplit(proj6, " "))
proj5_parts[!is.element(proj5_parts, proj6_parts)]
proj6_parts[!is.element(proj6_parts, proj5_parts)]


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
b_pump_sf1 <- b_pump_sf
st_crs(b_pump_sf1) <- st_crs(st_crs(b_pump_sf1)$proj4string)


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
Sys.setenv("PROJ_NETWORK"="OFF")
sf_proj_network(FALSE)
list.files(sf_proj_search_paths()[1])
b_pump_sf_ll <- st_transform(b_pump_sf, "OGC:CRS84")
list.files(sf_proj_search_paths()[1])
b_pump_sf1_ll <- st_transform(b_pump_sf1, "OGC:CRS84")
list.files(sf_proj_search_paths()[1])
sf_use_s2(FALSE)
st_distance(b_pump_sf_ll, b_pump_sf1_ll)


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
library(mapview)
if (sf:::CPL_gdal_version() >= "3.1.0") mapviewOptions(fgb = FALSE)
pts <- rbind(b_pump_sf_ll, b_pump_sf1_ll)
pts$CRS <- c("original", "degraded")
mapview(pts, zcol="CRS", map.type="OpenStreetMap", col.regions=c("green", "red"), cex=18)


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
st_crs("EPSG:4326")


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
library(sp)
cat(wkt(CRS("EPSG:4326")), "\n")


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
sf_from_sp <- st_crs(CRS("EPSG:4326"))
o <- strsplit(sf_from_sp$wkt, "\n")[[1]]
cat(paste(o[grep("CS|AXIS|ORDER", o)], collapse="\n"))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
sp_from_sf <- as(st_crs("EPSG:4326"), "CRS")
o <- strsplit(wkt(sp_from_sf), "\n")[[1]]
cat(paste(o[grep("CS|AXIS|ORDER", o)], collapse="\n"))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
cat(st_crs("OGC:CRS:84")$wkt, "\n")


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
cat(wkt(CRS("OGC:CRS84")), "\n")


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
(o <- sf_proj_pipelines(st_crs(b_pump_sf), "OGC:CRS84"))


## ------------------------------------------------------------------------------------------
as.data.frame(o)[,c(5,8)]


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
aoi0 <- sf_project(st_crs(b_pump_sf), "OGC:CRS84", matrix(unclass(st_bbox(b_pump_sf)), 2, 2, byrow=TRUE))
aoi <- c(t(aoi0 + c(-0.1, +0.1)))
(o_aoi <- sf_proj_pipelines(st_crs(b_pump_sf), "OGC:CRS84", AOI=aoi))


## ------------------------------------------------------------------------------------------
as.data.frame(o_aoi)[,c(5,8)]


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
(helm <- as.data.frame(o_aoi)[o_aoi$accuracy==2, "definition"])
b_pump_sf_ll <- st_transform(b_pump_sf, "OGC:CRS84", pipe=helm, aoi=aoi)


## ------------------------------------------------------------------------------------------
(o_aoi1 <- sf_proj_pipelines(st_crs(b_pump_sf1), "OGC:CRS84", AOI=aoi))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
b_pump_sf1_ll <- st_transform(b_pump_sf1, "OGC:CRS84")
st_distance(b_pump_sf_ll, b_pump_sf1_ll)


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
sf_proj_network()


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
Sys.setenv("PROJ_NETWORK"="ON")
sf_proj_network(TRUE)


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
(og <- sf_proj_pipelines(st_crs(b_pump_sf), "OGC:CRS84", AOI=aoi))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
list.files(sf_proj_search_paths()[1])
b_pump_sf_llgd <- st_transform(b_pump_sf, "OGC:CRS84")
list.files(sf_proj_search_paths()[1])


## ------------------------------------------------------------------------------------------
library(rgdal)
is_proj_CDN_enabled()
b_pump_sp_llgd <- spTransform(as(b_pump_sf, "Spatial"), "OGC:CRS84")
list.files(sf_proj_search_paths()[1])
DB <- file.path(DB0[1], "cache.db")
db <- dbConnect(SQLite(), dbname=DB)
cat(strwrap(paste(dbListTables(db), collapse=", ")), sep="\n")
dbReadTable(db, "chunks")
dbDisconnect(db)
b_pump_sf_llgdsp <- st_as_sf(b_pump_sp_llgd)


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
Sys.setenv("PROJ_NETWORK"="OFF")
sf_proj_network(FALSE)
c(st_distance(b_pump_sf_ll, b_pump_sf1_ll), st_distance(b_pump_sf_ll, b_pump_sf_llgd), st_distance(b_pump_sf_ll, b_pump_sf_llgdsp))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
sf_use_s2(TRUE)
c(st_distance(b_pump_sf_ll, b_pump_sf1_ll), st_distance(b_pump_sf_ll, b_pump_sf_llgd), st_distance(b_pump_sf_ll, b_pump_sf_llgdsp))
sf_use_s2(FALSE)


## ---- eval=TRUE----------------------------------------------------------------------------
df_tracts <- st_read("df_tracts.gpkg")


## ---- eval=TRUE----------------------------------------------------------------------------
chicago_MA <- read.table("Chicago_MA.txt", colClasses=c("character", "character"))
chicago_MA_tracts <- !is.na(match(substring(df_tracts$GEOID, 1, 5), chicago_MA$V2))
sum(chicago_MA_tracts)


## ---- eval=TRUE----------------------------------------------------------------------------
library(tmap)
tm_shape(df_tracts[chicago_MA_tracts,]) + tm_fill("med_inc_cv", style="fisher", n=7, title="Coefficient of Variation")


## ---- eval=TRUE----------------------------------------------------------------------------
df_tracts$mi_cv_esri <- cut(df_tracts$med_inc_cv, c(0, 0.12, 0.40, Inf), labels=c("High", "Medium", "Low"), right=TRUE, include.lowest=TRUE, ordered_result=TRUE)
table(df_tracts$mi_cv_esri)


## ---- eval=TRUE----------------------------------------------------------------------------
tm_shape(df_tracts[chicago_MA_tracts,]) + tm_fill("mi_cv_esri", title="Reliability")


## ---- eval=TRUE----------------------------------------------------------------------------
tmap_mode("view")
tm_shape(df_tracts[chicago_MA_tracts,]) + tm_fill("mi_cv_esri", title="Reliability")
tmap_mode("plot")


## ---- eval=FALSE---------------------------------------------------------------------------
## library(mapview)
## mapviewOptions(fgb = FALSE)
## mapview(df_tracts[chicago_MA_tracts,"med_inc_cv"], layer.name="Coefficient of Variation")


## ---- echo=TRUE----------------------------------------------------------------------------
library(classInt)
args(classIntervals)


## ---- echo=TRUE----------------------------------------------------------------------------
library(sf)
olinda_sirgas2000 <- st_read("olinda_sirgas2000.gpkg")
(cI <- classIntervals(olinda_sirgas2000$DEPRIV, n=7, style="fisher"))


## ---- echo = TRUE, eval=TRUE---------------------------------------------------------------
Sys.setenv("PROJ_NETWORK"="OFF")
sf_proj_network()
list.files(sf_proj_search_paths()[1])
sf_extSoftVersion()


## ---- echo=TRUE----------------------------------------------------------------------------
library(RColorBrewer)
pal <- RColorBrewer::brewer.pal((length(cI$brks)-1), "Reds")
plot(cI, pal)


## ---- echo=TRUE----------------------------------------------------------------------------
display.brewer.all()


## ---- echo=TRUE----------------------------------------------------------------------------
library(colorspace)
hcl_palettes("sequential (single-hue)", n = 7, plot = TRUE)


## ---- echo=TRUE, eval=FALSE----------------------------------------------------------------
## pal <- hclwizard()
## pal(6)


## ---- echo=TRUE----------------------------------------------------------------------------
wheel <- function(col, radius = 1, ...)
  pie(rep(1, length(col)), col = col, radius = radius, ...) 
opar <- par(mfrow=c(1,2))
wheel(rainbow_hcl(12))
wheel(rainbow(12))
par(opar)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(olinda_sirgas2000[,"DEPRIV"], breaks=cI$brks, pal=pal)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(olinda_sirgas2000[,"DEPRIV"], nbreaks=7, breaks="fisher", pal=pal)


## ---- echo=TRUE----------------------------------------------------------------------------
library(tmap)
tmap_mode("plot")
o <- tm_shape(olinda_sirgas2000) + tm_fill("DEPRIV", style="fisher", n=7, palette="Reds")
class(o)


## ---- echo=TRUE----------------------------------------------------------------------------
o


## ---- echo=TRUE----------------------------------------------------------------------------
o + tm_borders(alpha=0.5, lwd=0.5)


## ---- echo=TRUE, eval=FALSE----------------------------------------------------------------
## tmaptools::palette_explorer()


## ---- echo=TRUE----------------------------------------------------------------------------
library(mapsf)
cols <- mf_get_pal(n = c(5, 5), pal = c("Reds 2", "Greens"))
plot(1:10, rep(1, 10), bg = cols, pch = 22, cex = 4, axes=FALSE, ann=FALSE)


## ---- echo=TRUE----------------------------------------------------------------------------
mf_choro(olinda_sirgas2000, var="DEPRIV", breaks="fisher", nbreaks=7, pal=pal, leg_val_rnd=3)


## ---- echo=TRUE----------------------------------------------------------------------------
library(ggplot2)


## ---- echo=TRUE----------------------------------------------------------------------------
g <- ggplot(olinda_sirgas2000) + geom_sf(aes(fill=DEPRIV))
g


## ---- echo=TRUE----------------------------------------------------------------------------
g + theme_void()


## ---- echo=TRUE----------------------------------------------------------------------------
g + theme_void() + scale_fill_distiller(palette="Reds", direction=1)


## ---- echo=TRUE----------------------------------------------------------------------------
tmap_mode("view")


## ---- echo=TRUE----------------------------------------------------------------------------
o + tm_borders(alpha=0.5, lwd=0.5)


## ---- echo=TRUE----------------------------------------------------------------------------
tmap_mode("plot")


## ---- echo=TRUE----------------------------------------------------------------------------
library(mapview)
if (sf:::CPL_gdal_version() >= "3.1.0") mapviewOptions(fgb = FALSE)
mapview(olinda_sirgas2000, zcol="DEPRIV", col.regions=pal, at=cI$brks)


## ---- echo=TRUE----------------------------------------------------------------------------
data("pol_pres15", package = "spDataLarge")
pol_pres15 <- st_buffer(pol_pres15, dist=0)


## ---- echo=TRUE----------------------------------------------------------------------------
library(tmap)
o <- tm_shape(pol_pres15) + tm_facets(free.scales=FALSE) + tm_borders(lwd=0.5, alpha=0.4) + tm_layout(panel.labels=c("Duda", "Komorowski"))


## ---- echo=TRUE, cache=TRUE----------------------------------------------------------------
o + tm_fill(c("I_Duda_share", "I_Komorowski_share"), n=6, style="pretty", title="I round\nshare of votes")


## ---- echo=TRUE, cache=TRUE----------------------------------------------------------------
o + tm_fill(c("II_Duda_share", "II_Komorowski_share"), n=6, style="pretty", title="II round\nshare of votes")


## ----sI, echo = TRUE-----------------------------------------------------------------------
sessionInfo()

