

## ---- echo=TRUE----------------------------------------------------------------------------
needed <- c("tidycensus", "rgdal", "RSQLite", "units", "gdistance", "igraph", 
"stars", "abind", "raster", "terra", "sp", "mapview", "sf", "osmdata")


## ---- echo = TRUE--------------------------------------------------------------------------
suppressPackageStartupMessages(library(osmdata))
library(sf)


## ---- cache=TRUE, echo = TRUE--------------------------------------------------------------
bbox <- opq(bbox = 'bergen norway')
byb0 <- osmdata_sf(add_osm_feature(bbox, key = 'railway',
  value = 'light_rail'))$osm_lines
tram <- osmdata_sf(add_osm_feature(bbox, key = 'railway',
  value = 'tram'))$osm_lines
byb1 <- tram[!is.na(tram$name),]
o <- intersect(names(byb0), names(byb1))
byb <- rbind(byb0[,o], byb1[,o])
saveRDS(byb, file="byb.rds")


## ---- echo = TRUE--------------------------------------------------------------------------
byb <- readRDS("byb.rds")
library(mapview)
mapviewOptions(fgb = FALSE)
mapview(byb)


## ---- echo = TRUE--------------------------------------------------------------------------
library(sp)
byb_sp <- as(byb, "Spatial")
str(byb_sp, max.level=2)


## ---- echo = TRUE--------------------------------------------------------------------------
str(slot(byb_sp, "lines")[[1]])


## ---- echo = TRUE--------------------------------------------------------------------------
library(terra)
(byb_sv <- as(byb, "SpatVector"))
str(byb_sv)

## ---- echo = TRUE--------------------------------------------------------------------------
geomtype(byb_sv)
str(geom(byb_sv))


## ---- echo = TRUE, eval=FALSE--------------------------------------------------------------
## library(elevatr)
## elevation <- get_elev_raster(byb_sp, z = 10)
## is.na(elevation) <- elevation < 1
## saveRDS(elevation, file="elevation.rds")


## ---- echo = TRUE--------------------------------------------------------------------------
library(raster)
(elevation <- readRDS("elevation.rds"))
str(elevation, max.level=2)


## ---- echo=TRUE----------------------------------------------------------------------------
str(slot(elevation, "data"))


## ---- echo=TRUE----------------------------------------------------------------------------
str(as(elevation, "SpatialGridDataFrame"), max.level=2)


## ---- echo = TRUE, eval=TRUE, cache=TRUE---------------------------------------------------
mapview(elevation, col=terrain.colors)


## ---- echo = TRUE--------------------------------------------------------------------------
(elevation_sr <- as(elevation, "SpatRaster"))
str(elevation_sr)


## ---- echo = TRUE--------------------------------------------------------------------------
str(values(elevation_sr))


## ---- echo = TRUE, eval=FALSE, cache=TRUE--------------------------------------------------
## bike_fls <- list.files("bbs")
## trips0 <- NULL
## for (fl in bike_fls) trips0 <- rbind(trips0,
##   read.csv(file.path("bbs", fl), header=TRUE))
## trips0 <- trips0[trips0[, 8] < 6 & trips0[, 13] < 6,]
## trips <- cbind(trips0[,c(1, 4, 2, 9)], data.frame(count=1))
## from <- unique(trips0[,c(4,5,7,8)])
## names(from) <- substring(names(from), 7)
## to <- unique(trips0[,c(9,10,12,13)])
## names(to) <- substring(names(to), 5)
## stations0 <- st_as_sf(merge(from, to, all=TRUE),
##   coords=c("station_longitude", "station_latitude"))
## stations <- aggregate(stations0, list(stations0$station_id),
##   head, n=1)
## suppressWarnings(stations <- st_cast(stations, "POINT"))
## st_crs(stations) <- 4326
## saveRDS(stations, file="stations.rds")
## od <- aggregate(trips[,-(1:4)], list(trips$start_station_id,
##   trips$end_station_id), sum)
## od <- od[-(which(od[,1] == od[,2])),]
## library(stplanr)
## od_lines <- od2line(flow=od, zones=stations, zone_code="Group.1",
##   origin_code="Group.1", dest_code="Group.2")
## saveRDS(od_lines, "od_lines.rds")
## Sys.setenv(CYCLESTREET="31e77ac1d59a7f4b") #XxXxXxXxXxXxXx
## od_routes <- line2route(od_lines, plan = "fastest")
## saveRDS(od_routes, "od_routes.rds")


## ----plot3, cache=TRUE, eval=TRUE----------------------------------------------------------
od_lines <- readRDS("od_lines.rds")
stations <- readRDS("stations.rds")
mapviewOptions(fgb = FALSE)
mapview(od_lines, alpha=0.2, lwd=(od_lines$x/max(od_lines$x))*10) + mapview(stations)


## ----plot4, cache=TRUE, eval=TRUE----------------------------------------------------------
od_routes <- readRDS("od_routes.rds")
stations <- readRDS("stations.rds")
mapviewOptions(fgb = FALSE)
mapview(od_routes, alpha=0.2, lwd=(od_lines$x/max(od_lines$x))*10) + mapview(stations)


## ---- echo = TRUE--------------------------------------------------------------------------
V1 <- 1:3
V2 <- letters[1:3]
V3 <- sqrt(V1)
V4 <- sqrt(as.complex(-V1))
L <- list(v1=V1, v2=V2, v3=V3, v4=V4)


## ---- echo = TRUE--------------------------------------------------------------------------
str(L)
L$v3[2]
L[[3]][2]


## ---- echo = TRUE--------------------------------------------------------------------------
DF <- as.data.frame(L)
str(DF)
DF <- as.data.frame(L, stringsAsFactors=FALSE)
str(DF)


## ---- echo = TRUE--------------------------------------------------------------------------
V2a <- letters[1:4]
V4a <- factor(V2a)
La <- list(v1=V1, v2=V2a, v3=V3, v4=V4a)
DFa <- try(as.data.frame(La, stringsAsFactors=FALSE), silent=TRUE)
message(DFa)


## ---- echo = TRUE--------------------------------------------------------------------------
DF$v3[2]
DF[[3]][2]
DF[["v3"]][2]


## ---- echo = TRUE--------------------------------------------------------------------------
DF[2, 3]
DF[2, "v3"]
str(DF[2, 3])
str(DF[2, 3, drop=FALSE])


## ---- echo = TRUE--------------------------------------------------------------------------
as.matrix(DF)
as.matrix(DF[,c(1,3)])


## ---- echo = TRUE--------------------------------------------------------------------------
length(L)
length(DF)
length(as.matrix(DF))


## ---- echo = TRUE--------------------------------------------------------------------------
dim(L)
dim(DF)
dim(as.matrix(DF))


## ---- echo = TRUE--------------------------------------------------------------------------
str(as.matrix(DF))


## ---- echo = TRUE--------------------------------------------------------------------------
row.names(DF)
names(DF)
names(DF) <- LETTERS[1:4]
names(DF)
str(dimnames(as.matrix(DF)))


## ---- echo = TRUE--------------------------------------------------------------------------
str(attributes(DF))
str(attributes(as.matrix(DF)))


## ---- echo = TRUE--------------------------------------------------------------------------
V1a <- c(V1, NA)
V3a <- sqrt(V1a)
La <- list(v1=V1a, v2=V2a, v3=V3a, v4=V4a)
DFa <- as.data.frame(La, stringsAsFactors=FALSE)
str(DFa)


## ---- echo = TRUE--------------------------------------------------------------------------
DF$E <- list(d=1, e="1", f=TRUE)
str(DF)


## ---- echo = TRUE--------------------------------------------------------------------------
pt1 <- st_point(c(1,3))
pt2 <- pt1 + 1
pt3 <- pt2 + 1
str(pt3)


## ---- echo = TRUE--------------------------------------------------------------------------
st_as_text(pt3)


## ---- echo = TRUE--------------------------------------------------------------------------
st_as_binary(pt3)


## ---- echo = TRUE--------------------------------------------------------------------------
pt_sfc <- st_as_sfc(list(pt1, pt2, pt3))
str(pt_sfc)


## ---- echo = TRUE--------------------------------------------------------------------------
st_geometry(DF) <- pt_sfc
(DF)


## ---- echo = TRUE--------------------------------------------------------------------------
(buf_DF <- st_buffer(DF, dist=0.3))


## ---- echo = TRUE--------------------------------------------------------------------------
library(stars)
fn <- system.file("tif/L7_ETMs.tif", package = "stars")
L7 <- read_stars(fn)
L7


## ---- echo = TRUE--------------------------------------------------------------------------
(L7_R <- as(L7, "Raster"))
(as(L7_R, "SpatRaster"))


## ---- echo = TRUE--------------------------------------------------------------------------
ndvi <- function(x) (x[4] - x[3])/(x[4] + x[3])
(s2.ndvi <- st_apply(L7, c("x", "y"), ndvi))


## ---- echo = TRUE--------------------------------------------------------------------------
L7p <- read_stars(fn, proxy=TRUE)
L7p


## ---- echo = TRUE--------------------------------------------------------------------------
(L7p.ndvi = st_apply(L7p, c("x", "y"), ndvi))


## ---- echo = TRUE--------------------------------------------------------------------------
(x6 <- split(L7, "band"))


## ---- echo = TRUE--------------------------------------------------------------------------
x6$mean <- (x6[[1]] + x6[[2]] + x6[[3]] + x6[[4]] + x6[[5]] +
              x6[[6]])/6
xm <- st_apply(L7, c("x", "y"), mean)
all.equal(xm[[1]], x6$mean)


## ------------------------------------------------------------------------------------------
byb <- readRDS("byb.rds")
names(attributes(byb))


## ------------------------------------------------------------------------------------------
library(sf)
st_agr(byb)


## ------------------------------------------------------------------------------------------
byb$length <- st_length(byb)
summary(byb$length)


## ------------------------------------------------------------------------------------------
str(byb$length)



## ---- echo=TRUE----------------------------------------------------------------------------
library(sf)
bbo <- st_read("snow/bbo.gpkg")


## ---- echo=TRUE, warning=FALSE-------------------------------------------------------------
buildings <- st_read("snow/buildings.gpkg", quiet=TRUE)
deaths <- st_read("snow/deaths.gpkg", quiet=TRUE)
sum(deaths$Num_Css)
b_pump <- st_read("snow/b_pump.gpkg", quiet=TRUE)
nb_pump <- st_read("snow/nb_pump.gpkg", quiet=TRUE)


## ---- echo=TRUE, warning=FALSE-------------------------------------------------------------
library(sf)
st_crs(buildings) <- st_crs(bbo)
buildings1 <- st_intersection(buildings, bbo)
buildings2 <- st_buffer(buildings1, dist=-4)


## ---- echo=TRUE, warning=FALSE-------------------------------------------------------------
plot(st_geometry(buildings2))


## ---- echo=TRUE----------------------------------------------------------------------------
library(raster)
resolution <- 1
r <- raster(extent(buildings2), resolution=resolution, crs=st_crs(bbo)$proj4string)
r[] <- resolution
summary(r)


## ---- echo=TRUE, cache=TRUE, warning=FALSE-------------------------------------------------
buildings3 <- as(buildings2[!st_is_empty(buildings2),], "Spatial")
cfp <- cellFromPolygon(r, buildings3)
is.na(r[]) <- unlist(cfp)
summary(r)


## ---- echo=TRUE, warning=FALSE-------------------------------------------------------------
plot(r)


## ---- echo=TRUE, warning=FALSE, message=FALSE----------------------------------------------
library(gdistance)


## ---- echo=TRUE, cache=TRUE----------------------------------------------------------------
tr1 <- transition(r, transitionFunction=function(x) 1/mean(x), directions=8, symm=TRUE)


## ---- echo=TRUE, cache=TRUE, warning=FALSE-------------------------------------------------
sp_deaths <- as(deaths, "Spatial")
d_b_pump <- st_length(st_as_sfc(shortestPath(tr1, as(b_pump, "Spatial"), sp_deaths, output="SpatialLines")))


## ---- echo=TRUE, cache=TRUE, warning=FALSE-------------------------------------------------
res <- matrix(NA, ncol=nrow(nb_pump), nrow=nrow(deaths))
sp_nb_pump <- as(nb_pump, "Spatial")
for (i in 1:nrow(nb_pump)) res[,i] <- st_length(st_as_sfc(shortestPath(tr1, sp_nb_pump[i,], sp_deaths, output="SpatialLines")))
d_nb_pump <- apply(res, 1, min)


## ---- echo=TRUE----------------------------------------------------------------------------
library(units)
units(d_nb_pump) <- "m"
deaths$b_nearer <- d_b_pump < d_nb_pump
by(deaths$Num_Css, deaths$b_nearer, sum)


## ------------------------------------------------------------------------------------------
sf_extSoftVersion()


## ------------------------------------------------------------------------------------------
sort(as.character(st_drivers("vector")$name))


## ------------------------------------------------------------------------------------------
sort(as.character(st_drivers("raster")$name))


## ------------------------------------------------------------------------------------------
library(RSQLite)
db = dbConnect(SQLite(), dbname="snow/b_pump.gpkg")
dbListTables(db)


## ------------------------------------------------------------------------------------------
str(dbReadTable(db, "gpkg_geometry_columns"))


## ------------------------------------------------------------------------------------------
str(dbReadTable(db, "b_pump")$geom)


## ------------------------------------------------------------------------------------------
dbDisconnect(db)


## ------------------------------------------------------------------------------------------
str(st_layers("snow/b_pump.gpkg"))


## ------------------------------------------------------------------------------------------
st_layers("snow/nb_pump.gpkg")


## ------------------------------------------------------------------------------------------
library(rgdal)
ogrInfo("snow/nb_pump.gpkg")


## ------------------------------------------------------------------------------------------
rgdal::GDALinfo(system.file("tif/L7_ETMs.tif", package = "stars"))


## ------------------------------------------------------------------------------------------
obj <- GDAL.open(system.file("tif/L7_ETMs.tif", package = "stars"))


## ------------------------------------------------------------------------------------------
dim(obj)


## ------------------------------------------------------------------------------------------
getDriverLongName(getDriver(obj))


## ------------------------------------------------------------------------------------------
image(getRasterData(obj, band=1, offset=c(100, 100), region.dim=c(200, 200)))


## ------------------------------------------------------------------------------------------
GDAL.close(obj)


## ------------------------------------------------------------------------------------------
library(raster)
(obj <- raster(system.file("tif/L7_ETMs.tif", package = "stars")))


## ---- eval=TRUE----------------------------------------------------------------------------
library(sf)
library(tidycensus)
options(tigris_use_cache=TRUE)


## ---- eval=FALSE---------------------------------------------------------------------------
## census_api_key("MY_KEY")


## ---- eval=TRUE----------------------------------------------------------------------------
(us <- unique(fips_codes$state)[c(1, 3:11, 13:51)])


## ---- eval=FALSE---------------------------------------------------------------------------
## f <- function(x) {
##   get_acs(geography="tract", variables=c(tot_pop="B01003_001"), year=2010,
##           state=x, geometry=TRUE)
## }
## mp <- lapply(us, f)
## map10 <- do.call("rbind", mp)


## ---- eval=FALSE---------------------------------------------------------------------------
## f <- function(x) {
##   get_acs(geography="tract", variables=c(median_income="B19013_001"), year=2010, state=x)
## }
## mp <- lapply(us, f)
## med_inc_acs10 <- do.call("rbind", mp)


## ---- eval=FALSE---------------------------------------------------------------------------
## f <- function(x) {
##   get_decennial(geography="tract", variables=c(tot_pop="P001001", tot_hu="H001001", vacant="H003003", group_pop="P042001", black_tot="P008004", hisp_tot="P004003", m70_74="P012022", m75_79="P012023", m80_84="P012024", m85p="P012025", f70_74="P012046", f75_79="P012047", f80_84="P012048", f85p="P012049"), year=2010, state=x, output="wide")
## }
## mp <- lapply(us, f)
## cen10 <- do.call("rbind", mp)


## ---- eval=FALSE---------------------------------------------------------------------------
## df <- merge(map10, med_inc_acs10, by="GEOID")
## df1 <- df[,-c(2, 3, 6, 7)]
## names(df1) <- c("GEOID", "tot_pop_acs", "tot_pop_moe", "med_inc_acs", "med_inc_moe", "geometry")
## names(attr(df1, "agr")) <- names(df1)[-6]


## ---- eval=FALSE---------------------------------------------------------------------------
## df_tracts_a <- merge(df1, cen10, by="GEOID")
## df_tracts <- df_tracts_a[df_tracts_a$tot_pop > 500 & df_tracts_a$tot_hu > 200,]
## df_tracts <- df_tracts[!is.na(df_tracts$med_inc_moe),]


## ---- eval=FALSE---------------------------------------------------------------------------
## df_tracts$tot_pop_cv <- (df_tracts$tot_pop_moe/1.645)/df_tracts$tot_pop_acs
## df_tracts$med_inc_cv <- (df_tracts$med_inc_moe/1.645)/df_tracts$med_inc_acs


## ---- eval=FALSE---------------------------------------------------------------------------
## df_tracts$old_rate <- sum(as.data.frame(df_tracts)[,13:20])/df_tracts$tot_pop
## df_tracts$black_rate <- df_tracts$black_tot/df_tracts$tot_pop
## df_tracts$hisp_rate <- df_tracts$hisp_tot/df_tracts$tot_pop
## df_tracts$vacancy_rate <- df_tracts$vacant/df_tracts$tot_hu


## ---- eval=FALSE---------------------------------------------------------------------------
## library(s2)
## df_tracts$area <- NISTunits::NISTsqrMeterTOacre(st_area(df_tracts))
## df_tracts$dens <- df_tracts$tot_pop/df_tracts$area
## st_write(df_tracts, "df_tracts.gpkg", append=FALSE)


## ---- eval=TRUE----------------------------------------------------------------------------
library(sf)
st_layers("Basisdata_0000_Norge_4258_Grunnkretser_GML.gml")
gdal_utils("vectortranslate", "Basisdata_0000_Norge_4258_Grunnkretser_GML.gml", "Basisdata_0000_Norge_4258_Grunnkretser_GML.gpkg", options=c("-f", "GPKG", "-nlt", "CONVERT_TO_LINEAR", "-overwrite"))
st_layers("Basisdata_0000_Norge_4258_Grunnkretser_GML.gpkg")
gk <- st_read("Basisdata_0000_Norge_4258_Grunnkretser_GML.gpkg", "Grunnkrets")


## ----sI, echo = TRUE-----------------------------------------------------------------------
sessionInfo()

