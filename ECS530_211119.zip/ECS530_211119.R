
## ---- echo=TRUE----------------------------------------------------------------------------
needed <- c("stars", "abind", "raster", "spatstat", "spatstat.linnet", "spatstat.core",
"spatstat.geom", "spatstat.data", "ranger", "automap", "RColorBrewer", "gstat",
"ggplot2", "R2BayesX", "colorspace", "HSAR", "hglm", "sp", "lme4", "spfilteR",
"spmoran", "spatialreg", "spData", "tmap", "sf")


## ---- echo=TRUE----------------------------------------------------------------------------
library(sf)
NY8 <- st_read(system.file("shapes/NY8_utm18.shp", package="spData"))
NY8 <- st_buffer(NY8, dist=0)


## ---- echo=TRUE----------------------------------------------------------------------------
library(tmap)
tm_shape(NY8) + tm_fill("Z", midpoint=0)


## ---- echo=TRUE----------------------------------------------------------------------------
NY_nb <- spdep::poly2nb(NY8)
NY_lwB <- spdep::nb2listw(NY_nb, style="B")
NY_lwW <- spdep::nb2listw(NY_nb, style="W")


## ---- echo=TRUE----------------------------------------------------------------------------
library(spatialreg)
gform <- Z ~ PEXPOSURE + PCTAGE65P + PCTOWNHOME
mod1 <- spautolm(gform, data=NY8, family="CAR", listw=NY_lwB, weights=POP8)
summary(mod1)


## ---- echo=TRUE----------------------------------------------------------------------------
(SF0 <- SpatialFiltering(gform, data = NY8, nb=NY_nb, style="W"))


## ---- echo=TRUE----------------------------------------------------------------------------
SF_obj2 <- lm(update(gform, . ~ . + fitted(SF0)), data = NY8)
summary(SF_obj2)


## ---- echo=TRUE----------------------------------------------------------------------------
spdep::lm.morantest(SF_obj2, NY_lwW)


## ---- echo=TRUE----------------------------------------------------------------------------
vecs <- fitted(SF0)
pvecs <- vecs %*% diag(coefficients(SF_obj2)[5:14])
colnames(pvecs) <- colnames(vecs)


## ---- echo=TRUE----------------------------------------------------------------------------
set.seed(22)
(ME0 <- ME(gform, data = NY8, listw=NY_lwW, alpha=0.15, nsim=99))


## ---- echo=TRUE----------------------------------------------------------------------------
ME_obj2 <- lm(update(gform, . ~ . + fitted(ME0)), data = NY8)
summary(ME_obj2)


## ---- echo=TRUE----------------------------------------------------------------------------
mvecs <- fitted(ME0) %*% diag(coefficients(ME_obj2)[5:7])
sem_obj2a <- spautolm(gform, NY8, listw=NY_lwW)
W <- as(NY_lwW, "CsparseMatrix")
SAR_ssre <- 2*as.vector((sem_obj2a$lambda * W) %*% sem_obj2a$Y - (sem_obj2a$lambda * W) %*% (sem_obj2a$X %*% sem_obj2a$fit$coefficients))


## ---- echo=TRUE----------------------------------------------------------------------------
library(spmoran)
centroids_utm <- st_centroid(st_geometry(NY8))
meig <- meigen(st_coordinates(centroids_utm))


## ---- echo=TRUE----------------------------------------------------------------------------
y <- model.response(model.frame(gform, NY8))
X <- model.matrix(update(gform, ~ .), NY8)
(esf_obj2 <- esf(y, X, meig=meig))

## ------------------------------------------------------------------------------------------
esf_obj2$r


## ---- echo=TRUE----------------------------------------------------------------------------
r_used_eigs <- row.names(esf_obj2$r)
used_eigs <- as.integer(substring(r_used_eigs, 3))
evecs <- meig$sf[, used_eigs] %*% diag(esf_obj2$r[1:length(r_used_eigs),1])
colnames(evecs) <- r_used_eigs


## ---- echo=TRUE----------------------------------------------------------------------------
library(spfilteR)
set.seed(1)
spfMI_obj <- lmFilter(y=y, x=X[,-1], W=as.matrix(W), objfn="MI", positive = FALSE, tol = .2)
summary(spfMI_obj)


## ---- echo=TRUE----------------------------------------------------------------------------
spfvecs <- spfMI_obj$selvecs %*% diag(spfMI_obj$EV[,1])


## ---- echo=TRUE----------------------------------------------------------------------------
SEs <- cbind("ESF"=apply(evecs, 1, sum), "SF"=apply(pvecs, 1, sum), "SPF"=apply(spfvecs, 1, sum), "ME"=apply(mvecs, 1, sum), "SAR"=SAR_ssre)
NY8_SEs <- cbind(NY8, SEs)
mat <- cor(SEs)
colnames(mat) <- rownames(mat) <- c("ESF", "SF", "SPF", "ME", "SAR")
mat


## ------------------------------------------------------------------------------------------
tm_shape(NY8_SEs) + tm_fill(c("ESF", "SF", "SPF", "ME", "SAR"), n=8, palette="BrBG", midpoint=0, title="Spatial effect") + tm_facets(free.scales=FALSE) + tm_borders(lwd=0.5) + tm_layout(panel.labels=c("ESF", "SF", "SPF", "ME", "SAR"), bg="grey90")


## ---- message=FALSE, warning=FALSE---------------------------------------------------------
nc <- st_read(system.file("shapes/sids.shp", package="spData")[1], quiet=TRUE)
st_crs(nc) <- "EPSG:4267"
row.names(nc) <- as.character(nc$FIPSNO)
nc$ft.SID74 <- sqrt(1000)*(sqrt(nc$SID74/nc$BIR74) + sqrt((nc$SID74+1)/nc$BIR74))
nc$ft.NWBIR74 <- sqrt(1000)*(sqrt(nc$NWBIR74/nc$BIR74) + sqrt((nc$NWBIR74+1)/nc$BIR74))
gal_file <- system.file("weights/ncCR85.gal", package="spData")[1]
ncCR85 <- spdep::read.gal(gal_file, region.id=nc$FIPSNO)
nc_lw <- spdep::nb2listw(ncCR85, style="B")
nc_W <- as(nc_lw, "CsparseMatrix")


## ---- echo=TRUE----------------------------------------------------------------------------
E <- nc$BIR74 * sum(nc$SID74)/sum(nc$BIR74)
set.seed(1001)
(ME_nc_p <- ME(SID74 ~ ft.NWBIR74, offset=log(E), weights=BIR74, data=nc, family=poisson(link=log), listw=nc_lw, alpha=0.25, nsim=499))


## ---- echo=TRUE----------------------------------------------------------------------------
ME_obj_nc0 <- glm(SID74 ~ ft.NWBIR74, offset=log(E), weights=BIR74, data=nc, family=poisson(link=log))
summary(ME_obj_nc0)


## ---- echo=TRUE----------------------------------------------------------------------------
ME_obj_nc <- glm(update(SID74 ~ ft.NWBIR74, . ~ . + fitted(ME_nc_p)), offset=log(E), weights=BIR74, data=nc, family=poisson(link=log))
summary(ME_obj_nc)


## ------------------------------------------------------------------------------------------
anova(ME_obj_nc0, ME_obj_nc, test="Chisq")


## ------------------------------------------------------------------------------------------
boston_506 <- st_read(system.file("shapes/boston_tracts.shp", package="spData")[1])

## ------------------------------------------------------------------------------------------
nb_q <- spdep::poly2nb(boston_506)
lw_q <- spdep::nb2listw(nb_q, style="W")


## ------------------------------------------------------------------------------------------
boston_506$CHAS <- as.factor(boston_506$CHAS)
boston_489 <- boston_506[!is.na(boston_506$median),]
nb_q_489 <- spdep::poly2nb(boston_489)
lw_q_489 <- spdep::nb2listw(nb_q_489, style="W", zero.policy=TRUE)


## ------------------------------------------------------------------------------------------
agg_96 <- list(as.character(boston_506$NOX_ID))
boston_96 <- aggregate(boston_506[, "NOX_ID"], by=agg_96, unique)
nb_q_96 <- spdep::poly2nb(boston_96)
lw_q_96 <- spdep::nb2listw(nb_q_96)
boston_96$NOX <- aggregate(boston_506$NOX, agg_96, mean)$x
boston_96$CHAS <- aggregate(as.integer(boston_506$CHAS)-1, agg_96, max)$x


## ------------------------------------------------------------------------------------------
nms <- names(boston_506)
ccounts <- 23:31
for (nm in nms[c(22, ccounts, 36)]) {
  boston_96[[nm]] <- aggregate(boston_506[[nm]], agg_96, sum)$x
}
br2 <- c(3.50,  6.25,  8.75, 12.50, 17.50, 22.50, 30.00, 42.50, 60.00)*1000
counts <- as.data.frame(boston_96)[, nms[ccounts]]
f <- function(x) matrixStats::weightedMedian(x=br2, w=x, interpolate=TRUE)
boston_96$median <- apply(counts, 1, f)
is.na(boston_96$median) <- boston_96$median > 50000
summary(boston_96$median)


## ---- echo=FALSE---------------------------------------------------------------------------
POP <- boston_506$POP
f <- function(x) matrixStats::weightedMean(x[,1], x[,2])
for (nm in nms[c(9:11, 14:19, 21, 33)]) {
  s0 <- split(data.frame(boston_506[[nm]], POP), agg_96)
  boston_96[[nm]] <- sapply(s0, f)
}

## ------------------------------------------------------------------------------------------
boston_94 <- boston_96[!is.na(boston_96$median),]
nb_q_94 <- spdep::subset.nb(nb_q_96, !is.na(boston_96$median))
lw_q_94 <- spdep::nb2listw(nb_q_94, style="W")


## ------------------------------------------------------------------------------------------
boston_94a <- aggregate(boston_489[,"NOX_ID"], list(boston_489$NOX_ID), unique)
nb_q_94a <- spdep::poly2nb(boston_94a)
NOX_ID_no_neighs <- boston_94a$NOX_ID[which(spdep::card(nb_q_94a) == 0)]
boston_487 <- boston_489[is.na(match(boston_489$NOX_ID, NOX_ID_no_neighs)),]
boston_93 <- aggregate(boston_487[, "NOX_ID"], list(ids = boston_487$NOX_ID), unique)
row.names(boston_93) <- as.character(boston_93$NOX_ID)
nb_q_93 <- spdep::poly2nb(boston_93, row.names=unique(as.character(boston_93$NOX_ID)))


## ------------------------------------------------------------------------------------------
form <- formula(log(median) ~ CRIM + ZN + INDUS + CHAS + I((NOX*10)^2) + I(RM^2) + 
                  AGE + log(DIS) + log(RAD) + TAX + PTRATIO + I(BB/100) + 
                  log(I(LSTAT/100)))


## ------------------------------------------------------------------------------------------
library(lme4)
MLM <- lmer(update(form, . ~ . + (1 | NOX_ID)), data=boston_487, REML=FALSE)


## ------------------------------------------------------------------------------------------
boston_93$MLM_re <- ranef(MLM)[[1]][,1]


## ------------------------------------------------------------------------------------------
library(Matrix)
suppressMessages(library(MatrixModels))
Delta <- as(model.Matrix(~ -1 + as.factor(NOX_ID), data=boston_487, sparse=TRUE),
            "dgCMatrix")
M <- as(spdep::nb2listw(nb_q_93, style="B"), "CsparseMatrix")


## ------------------------------------------------------------------------------------------
suppressPackageStartupMessages(library(hglm))
y_hglm <- log(boston_487$median)
X_hglm <- model.matrix(lm(form, data=boston_487))
suppressWarnings(HGLM_iid <- hglm(y=y_hglm, X=X_hglm, Z=Delta))


## ------------------------------------------------------------------------------------------
suppressWarnings(HGLM_sar <- hglm(y=y_hglm, X=X_hglm, Z=Delta, rand.family=SAR(D=M)))
boston_93$HGLM_re <- unname(HGLM_iid$ranef)
boston_93$HGLM_ss <- HGLM_sar$ranef[,1]


## ------------------------------------------------------------------------------------------
library(HSAR)
suppressWarnings(HSAR <- hsar(form, data=boston_487, W=NULL, M=M, Delta=Delta, 
                              burnin=500, Nsim=2500, thinning=1))
boston_93$HSAR_ss <- HSAR$Mus[1,]


## ------------------------------------------------------------------------------------------
suppressPackageStartupMessages(library(R2BayesX))
BX_iid <- bayesx(update(form, . ~ . + sx(NOX_ID, bs="re")), family="gaussian",
data=boston_487, method="MCMC", iterations=12000, burnin=2000, step=2, seed=123)
boston_93$BX_re <- BX_iid$effects["sx(NOX_ID):re"][[1]]$Mean


## ------------------------------------------------------------------------------------------
RBX_gra <- nb2gra(nb_q_93)
BX_mrf <- bayesx(update(form, . ~ . + sx(NOX_ID, bs="mrf", map=RBX_gra)), 
                 family="gaussian", data=boston_487, method="MCMC", 
                 iterations=12000, burnin=2000,step=2, seed=123)
boston_93$BX_ss <- BX_mrf$effects["sx(NOX_ID):mrf"][[1]]$Mean


## ------------------------------------------------------------------------------------------
library(mgcv)
names(nb_q_93) <- attr(nb_q_93, "region.id")
boston_487$NOX_ID <- as.factor(boston_487$NOX_ID)
GAM_MRF <- gam(update(form, . ~ . + s(NOX_ID, bs="mrf", xt=list(nb=nb_q_93))),
               data=boston_487, method="REML")
boston_93$GAM_ss <- aggregate(predict(GAM_MRF, type="terms", se=FALSE)[,14],
                              list(boston_487$NOX_ID), mean)$x


## ------------------------------------------------------------------------------------------
res <- rbind(iid_lmer=summary(MLM)$coefficients[6, 1:2],
             iid_hglm=summary(HGLM_iid)$FixCoefMat[6, 1:2], 
             iid_BX=BX_iid$fixed.effects[6, 1:2], 
             sar_hsar=c(HSAR$Mbetas[1, 6], HSAR$SDbetas[1, 6]),
             mrf_BX=BX_mrf$fixed.effects[6, 1:2], 
             mrf_GAM=c(summary(GAM_MRF)$p.coeff[6], summary(GAM_MRF)$se[6]))


## ----multi-levelcoefs----------------------------------------------------------------------
suppressPackageStartupMessages(library(ggplot2))
df_res <- as.data.frame(res)
names(df_res) <- c("mean", "sd")
limits <- aes(ymax = mean + qnorm(0.975)*sd, ymin=mean + qnorm(0.025)*sd)
df_res$model <- row.names(df_res)
p <- ggplot(df_res, aes(y=mean, x=model)) + geom_point() + geom_errorbar(limits) + geom_hline(yintercept = 0, col="#EB811B") + coord_flip()
p + ggtitle("NOX coefficients and error bars") + theme(plot.background = element_rect(fill = "transparent",colour = NA), legend.background = element_rect(colour = NA, fill = "transparent"))


## ----multi-levelmaps1----------------------------------------------------------------------
library(tmap)
tm_shape(boston_93) + tm_fill(c("MLM_re", "HGLM_re" , "BX_re"), midpoint=0, title="IID")  + tm_facets(free.scales=FALSE) + tm_borders(lwd=0.3, alpha=0.4) + tm_layout(panel.labels=c("MLM", "HGLM", "BX"))


## ----multilevelmaps2, out.width='100%', fig.cap="Spatially structured random effects", fig=TRUE----
tm_shape(boston_93) + tm_fill(c("HGLM_ss", "HSAR_ss", "BX_ss", "GAM_ss"), midpoint=0, title="SS")  + tm_facets(free.scales=FALSE) + tm_borders(lwd=0.3, alpha=0.4) + tm_layout(panel.labels=c("HGLM SAR", "HSAR SAR", "BX MRF", "GAM MRF"))


## ---- message=FALSE, warning=FALSE---------------------------------------------------------
nc <- st_read(system.file("shapes/sids.shp", package="spData")[1], quiet=TRUE)
st_crs(nc) <- "EPSG:4267"
row.names(nc) <- as.character(nc$FIPSNO)
nc$ft.SID74 <- sqrt(1000)*(sqrt(nc$SID74/nc$BIR74) + sqrt((nc$SID74+1)/nc$BIR74))
nc$ft.NWBIR74 <- sqrt(1000)*(sqrt(nc$NWBIR74/nc$BIR74) + sqrt((nc$NWBIR74+1)/nc$BIR74))
gal_file <- system.file("weights/ncCR85.gal", package="spData")[1]
ncCR85 <- spdep::read.gal(gal_file, region.id=nc$FIPSNO)
nc_lw <- spdep::nb2listw(ncCR85, style="B")
nc_W <- as(nc_lw, "CsparseMatrix")


## ---- echo=TRUE, results='hide', message=FALSE, warning=FALSE------------------------------
m1 <- spautolm(ft.SID74 ~ ft.NWBIR74, weights=BIR74, data=nc, listw=nc_lw, family="SAR")


## ---- echo=TRUE----------------------------------------------------------------------------
summary(m1)


## ---- echo=TRUE----------------------------------------------------------------------------
nc$SAR_ssre <- 2*as.vector((m1$lambda * nc_W) %*% m1$Y - (m1$lambda * nc_W) %*% (m1$X %*% m1$fit$coefficients))
library(tmap)
tm_shape(nc) + tm_fill(c("ft.SID74", "SAR_ssre"), midpoint=c(NA, 0))


## ---- echo=TRUE, message=FALSE, warning=FALSE----------------------------------------------
m1a <- errorsarlm(ft.SID74 ~ ft.NWBIR74, weights=BIR74, data=nc, listw=nc_lw)
summary(m1a, Hausman=TRUE)


## ---- echo=TRUE, message=FALSE, warning=FALSE----------------------------------------------
m1b <- errorsarlm(ft.SID74 ~ ft.NWBIR74, weights=BIR74, data=nc, listw=nc_lw, Durbin=TRUE)
summary(m1b, Hausman=TRUE)


## ---- echo=TRUE, message=FALSE, warning=FALSE----------------------------------------------
summary(impacts(m1b))


## ---- echo=TRUE, results='hide', message=FALSE, warning=FALSE------------------------------
library(hglm)
E <- nc$BIR74 * sum(nc$SID74)/sum(nc$BIR74)
HGLM_iid <- hglm(fixed=SID74 ~ ft.NWBIR74, random= ~ 1|CRESS_ID, offset=log(E), weights=BIR74,
                 data=nc, family=poisson(link=log))


## ---- echo=TRUE----------------------------------------------------------------------------
ranef_iid <- unname(summary(HGLM_iid, print.ranef=TRUE)$RandCoefMat)
metafor::forest(ranef_iid[,1], ranef_iid[,2], subset=order(ranef_iid[,1], decreasing=TRUE), 
        slab=NA, annotate=FALSE, lty=c("solid","blank"), pch=19, psize=2, cex.lab=1, cex.axis=1)


## ---- echo=TRUE, results='hide', message=FALSE, cache=TRUE, warning=FALSE------------------
HGLM_sar <- hglm(fixed=SID74 ~ ft.NWBIR74, random= ~ 1|CRESS_ID, offset=log(E), weights=BIR74, 
                 data=nc, family=poisson(link=log), rand.family=SAR(D=nc_W))
ranef_sar <- unname(summary(HGLM_sar, print.ranef=TRUE)$RandCoefMat)
metafor::forest(ranef_sar[,1], ranef_sar[,2], subset=order(ranef_sar[,1], decreasing=TRUE), 
        slab=NA, annotate=FALSE, lty=c("solid","blank"), pch=19, psize=2, cex.lab=1, cex.axis=1)


## ---- echo=TRUE----------------------------------------------------------------------------
nc$HGLM_re <- ranef_iid[,1]
nc$HGLM_ss_SAR <- ranef_sar[,1]
tm_shape(nc) + tm_fill(c("HGLM_re", "HGLM_ss_SAR"), midpoint=c(0), title="Poisson HGLM RE") +
  tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("IID", "SAR SSRE"))


## ---- echo=TRUE----------------------------------------------------------------------------
m1c <- spautolm(ft.SID74 ~ ft.NWBIR74, weights=BIR74, data=nc, listw=nc_lw, family="CAR")
summary(m1c)


## ---- echo=TRUE----------------------------------------------------------------------------
nc$CAR_ssre <- as.vector((m1c$lambda * nc_W) %*% m1c$Y - 
                           (m1c$lambda * nc_W) %*% (m1c$X %*% m1c$fit$coefficients))
tm_shape(nc) + tm_fill(c("SAR_ssre", "CAR_ssre"), midpoint=c(0), title="Gauss ML RE") +
  tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("SAR SSRE", "CAR SSRE"))


## ---- echo=TRUE, results='hide', message=FALSE, cache=TRUE, warning=FALSE------------------
HGLM_car <- hglm(fixed=SID74 ~ ft.NWBIR74, random= ~ 1|CRESS_ID, offset=log(E), weights=BIR74, 
                 data=nc, family=poisson(link=log), rand.family=CAR(D=nc_W))
ranef_car <- unname(summary(HGLM_car, print.ranef=TRUE)$RandCoefMat)
metafor::forest(ranef_car[,1], ranef_car[,2], subset=order(ranef_car[,1], decreasing=TRUE), 
        slab=NA, annotate=FALSE, lty=c("solid","blank"), pch=19, psize=2, cex.lab=1, cex.axis=1)


## ---- echo=TRUE----------------------------------------------------------------------------
nc$HGLM_ss_CAR <- ranef_car[,1]
tm_shape(nc) + tm_fill(c("HGLM_ss_CAR", "HGLM_ss_SAR"), midpoint=c(0), title="Poisson HGLM RE") +
  tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("CAR SSRE", "SAR SSRE"))


## ---- echo=TRUE, results='hide', message=FALSE, cache=TRUE, warning=FALSE------------------
nc$LM <- as.numeric(interaction(nc$L_id, nc$M_id))
aggLM <- aggregate(nc[,"LM"], list(nc$LM), head, n=1)
aggnb <- spdep::poly2nb(aggLM)
library(mgcv)
names(aggnb) <- as.character(aggLM$Group.1)
nc$LM <- as.factor(nc$LM)
GAM_mrf <- gam(SID74 ~ s(ft.NWBIR74) + s(LM, bs="mrf", xt=list(nb=aggnb)), offset=log(E), weights=BIR74, data=nc, family=poisson(link=log))
summary(GAM_mrf)


## ---- echo=TRUE----------------------------------------------------------------------------
library(mgcv)
plot(GAM_mrf)


## ---- echo=TRUE----------------------------------------------------------------------------
GAM_mrf_re <- predict(GAM_mrf, type="terms", se=TRUE)
metafor::forest(GAM_mrf_re$fit[,2], GAM_mrf_re$se.fit[,2], subset=order(GAM_mrf_re$fit[,1], decreasing=TRUE), 
        slab=NA, annotate=FALSE, lty=c("solid","blank"), pch=19, psize=2, cex.lab=1, cex.axis=1)


## ---- echo=TRUE----------------------------------------------------------------------------
nc$GAM_mrf_re <- GAM_mrf_re$fit[,2]
tm_shape(nc) + tm_fill(c("GAM_mrf_re"), midpoint=c(0), title="Poisson GAM MRF RE")


## ------------------------------------------------------------------------------------------
df_tracts <- st_read("df_tracts.gpkg")


## ------------------------------------------------------------------------------------------
tr_form <- log(med_inc_cv) ~ log1p(vacancy_rate) + log1p(old_rate) + log1p(black_rate) + log1p(hisp_rate) + log1p(group_pop) + log1p(dens)


## ------------------------------------------------------------------------------------------
df_tracts$ST <- factor(substring(df_tracts$GEOID, 1, 2))
library(mgcv)
GAM_RE <- gam(update(tr_form, . ~ . + s(ST, bs="re")), data=df_tracts)
summary(GAM_RE)


## ---- cache=TRUE---------------------------------------------------------------------------
states <- aggregate(df_tracts["ST"], list(df_tracts$ST), head, n=1)
nb_st <- spdep::poly2nb(states, row.names=as.character(states$ST))
names(nb_st) <- as.character(states$ST)
GAM_MRF <- gam(update(tr_form, . ~ . + s(ST, bs="mrf", k=49, xt=list(nb=nb_st))), data=df_tracts)
summary(GAM_MRF)


## ------------------------------------------------------------------------------------------
cat(capture.output(print(anova(GAM_RE, GAM_MRF, test="Chisq")))[c(1, 2, 9:11)], sep="\n")


## ---- echo = TRUE--------------------------------------------------------------------------
library(geoR)
data(SIC)


## ---- echo = TRUE--------------------------------------------------------------------------
plot(sic.100, borders=sic.borders, lowess=TRUE)


## ---- echo = TRUE--------------------------------------------------------------------------
library(sf)
sic.100sf <- st_as_sf(cbind(as.data.frame(sic.100[[1]]), precip=sic.100[[2]], sic.100[[3]]), coords=1:2)
sic.allsf <- st_as_sf(cbind(as.data.frame(sic.all[[1]]), precip=sic.all[[2]], sic.all[[3]]), coords=1:2)


## ---- echo = TRUE--------------------------------------------------------------------------
library(gstat)
hscat(precip ~ altitude, data=sic.100sf, seq(0,120,20))


## ---- echo = TRUE--------------------------------------------------------------------------
g <- gstat(id="precip", formula=precip ~ altitude, data=sic.100sf)
evgm <- variogram(g, cutoff=100, width=5)
revgm <- variogram(g, cutoff=100, width=5, cressie=TRUE)
cevgm <- variogram(g, cutoff=100, width=5, cloud=TRUE)


## ---- echo = TRUE--------------------------------------------------------------------------
oopar <- par(mfrow=c(1,2))
plot(gamma ~ dist, cevgm, pch=".", cex=2, col="grey65", ylab="semivariance", xlab="distance")
lines(gamma ~ dist, evgm, lwd=2)
lines(gamma ~ dist, revgm, lwd=2, lty=2)
abline(v=seq(0,100,5), lty=2, col="grey50")
plot(gamma ~ dist, evgm, ylab="semivariance", xlab="distance", type="b", lwd=2)
points(gamma ~ dist, revgm, pch=3)
lines(gamma ~ dist, revgm, lty=2, lwd=2)
abline(v=seq(0,100,5), lty=2, col="grey50")
legend("topleft", legend=c("classic", "robust"), pch=c(1,3), lty=c(1,2), bty="n", lwd=2)
par(oopar)


## ---- echo = TRUE--------------------------------------------------------------------------
dbin <- findInterval(cevgm$dist, seq(0, 100, 5), all.inside=TRUE)
wid <- tapply(cevgm$gamma, dbin, length)
boxplot(cevgm$gamma ~ dbin, width=wid, ylab="semivariance", xlab="distance", axes=FALSE)
axis(2)
axis(1, at=c(0.5, 5.5, 10.5, 15.5, 20.5), labels=c(0, 25, 50, 75, 100)) 
box()
lines(gamma ~ I(dist/5), evgm, lwd=2, lty=2)


## ---- echo = TRUE--------------------------------------------------------------------------
mevgm <- variogram(g, cutoff=100, width=5, map=TRUE)
aevgm <- variogram(g, cutoff=100, width=5, alpha=c(0, 45, 90, 135))


## ---- echo=TRUE----------------------------------------------------------------------------
library(RColorBrewer)
oopar <- par(mar=c(1,1,1,1))
image(mevgm$map, col=colorRampPalette(brewer.pal(7, "Blues")[-(6:7)])(20))
abline(v=0, lty=1)
abline(a=0, b=1, lty=2)
abline(h=0, lty=3)
abline(a=0, b=-1, lty=4)
par(oopar)


## ---- echo=TRUE----------------------------------------------------------------------------
library(lattice)
trellis.device(new=FALSE,color=FALSE)
plot(aevgm, multipanel=FALSE)


## ---- echo = TRUE--------------------------------------------------------------------------
evg <- variog(sic.100, max.dist=200, trend=formula(~altitude), messages=FALSE)
fvg <- variofit(evg, messages=FALSE)
ml <- likfit(sic.100, ini.cov.pars=c(0.5, 0.5), trend=formula(~altitude), messages=FALSE)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(evg)
lines(fvg)
lines(ml, lty=2)
legend("topleft", legend=c("WLS", "ML"), lty=1:2, bty="n")


## ---- echo = TRUE--------------------------------------------------------------------------
evgm <- variogram(g, cutoff=200, width=5)
fevgm <- fit.variogram(evgm, vgm(psill=16000, model="Mat", range=30, nugget=1, kappa=0.5))
fevgm


## ---- echo=TRUE----------------------------------------------------------------------------
plot(evgm, model=fevgm)


## ---- echo = TRUE--------------------------------------------------------------------------
UK_fit <- gstat(g, id="precip", model=fevgm)
z <- predict(UK_fit, newdata=sic.allsf, debug.level=0)
sic.367sf <- sic.allsf[which(z$precip.var > 0.0001),]
z <- predict(UK_fit, newdata=sic.367sf, debug.level=0)


## ---- echo = TRUE, cache=TRUE--------------------------------------------------------------
kcwls <- krige.conv(sic.100, locations=st_coordinates(sic.367sf),
  krige=krige.control(obj.model=fvg, type.krige="OK",
  trend.d=formula(~altitude), trend.l=formula(~sic.367sf$altitude)))
kcml <- krige.conv(sic.100, locations=st_coordinates(sic.367sf),
 krige=krige.control(obj.model=ml, type.krige="OK",
 trend.d=formula(~altitude), trend.l=formula(~sic.367sf$altitude)))
kcB <- krige.bayes(sic.100, locations=st_coordinates(sic.367sf),
 model=model.control(trend.d=formula(~altitude),
 trend.l=formula(~sic.367sf$altitude)))


## ---- echo = TRUE--------------------------------------------------------------------------
plot(density(kcB$predictive$simulations[1,]), ylim=c(0, 0.006))
abline(v=kcB$predictive$mean[1], col="red", lwd=2)
curve(dnorm(x, mean=kcB$predictive$mean[1],
 sd=sqrt(kcB$predictive$variance[1])), lty=2, lwd=2, from=-100, to=500, add=TRUE)
abline(v=sic.367sf$precip[1], col="blue", lwd=2)


## ---- echo = TRUE--------------------------------------------------------------------------
library(automap)
aK <- autoKrige(formula=precip ~ altitude, input_data=as(sic.100sf, "Spatial"), new_data=as(sic.367sf, "Spatial"))
aK$var_model


## ---- echo=TRUE----------------------------------------------------------------------------
plot(aK)


## ---- echo = TRUE--------------------------------------------------------------------------
#grid.dist0 <- GSIF::buffer.dist(sic.100SP["precip"], sic.367SP[1], as.factor(1:nrow(sic.100SP)))
dist0sf <- as.data.frame(st_distance(st_geometry(sic.100sf)))
names(dist0sf) <- paste("layer", names(dist0sf), sep=".")
dist1sf <- as.data.frame(st_distance(st_geometry(sic.367sf), st_geometry(sic.100sf)))
names(dist1sf) <- paste("layer", names(dist1sf), sep=".")


## ---- echo = TRUE--------------------------------------------------------------------------
rm.precip <- cbind(data.frame(precip=sic.100sf$precip, altitude=sic.100sf$altitude), dist0sf)
rm.precip1 <- cbind(data.frame(altitude=sic.367sf$altitude), dist1sf)


## ---- echo = TRUE--------------------------------------------------------------------------
dn0 <- paste(names(dist0sf), collapse="+")
fm0 <- as.formula(paste("precip ~ altitude +", dn0))
#fm0


## ---- echo = TRUE--------------------------------------------------------------------------
library(ranger)
m.precip <- ranger(fm0, rm.precip, quantreg=TRUE, num.trees=150, seed=1)
m.precip


## ---- echo = TRUE--------------------------------------------------------------------------
quantiles <- c(pnorm(1, lower.tail=FALSE), 0.5, pnorm(1))
precip.rfd <- as.data.frame(predict(m.precip, rm.precip1, type="quantiles",
                                     quantiles=quantiles)$predictions)


## ---- echo = TRUE--------------------------------------------------------------------------
res <- cbind(sic.367sf[,"precip"], precip.rfd, as.data.frame(aK$krige_output)[,3:5])
res$rf_sd <- (res[[4]] - res[[2]])/2
names(res) <- make.names(names(res))
names(res)[c(2,4)] <- c("quantile= 0.159", "quantile= 0.841")


## ---- echo=TRUE----------------------------------------------------------------------------
library(tmap)
st_crs(res) <- 32662
tm_shape(res) + tm_symbols(col=c("precip", "var1.pred", "quantile..0.5"), pal="Blues", size=0.2) + tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("Preciptation", "Kriging predictons", "Random Forest predictions"))


## ---- echo=TRUE----------------------------------------------------------------------------
tm_shape(res) + tm_symbols(col=c("var1.stdev", "rf_sd"), pal="Reds", size=0.2) + tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("Kriging std. dev", "Random Forest 0.159-0.841 range"))


## ---- echo = TRUE--------------------------------------------------------------------------
xy100 <- st_coordinates(sic.100sf)
xy367 <- st_coordinates(sic.367sf)
rm.precipa <- cbind(rm.precip, x=xy100[,1], y=xy100[,2])
rm.precipa1 <- cbind(rm.precip1, x=xy367[,1], y=xy367[,2])


## ---- echo = TRUE--------------------------------------------------------------------------
fm1 <- update(fm0, . ~ . + x + y)


## ---- echo = TRUE--------------------------------------------------------------------------
m.precipa <- ranger(fm1, rm.precipa, quantreg=TRUE, num.trees=150, seed=1)
m.precipa


## ---- echo = TRUE--------------------------------------------------------------------------
quantiles <- c(pnorm(1, lower.tail=FALSE), 0.5, pnorm(1))
precipa.rfd <- as.data.frame(predict(m.precipa, rm.precipa1, type="quantiles",
                                     quantiles=quantiles)$predictions)


## ---- echo = TRUE--------------------------------------------------------------------------
resa <- cbind(sic.367sf[,"precip"], precipa.rfd, as.data.frame(aK$krige_output)[,3:5])
resa$rf_sda <- (resa[[4]] - resa[[2]])/2
names(resa) <- make.names(names(resa))
names(resa)[c(2,4)] <- c("quantile= 0.159", "quantile= 0.841")


## ---- echo=TRUE----------------------------------------------------------------------------
st_crs(resa) <- 32662
tm_shape(resa) + tm_symbols(col=c("precip", "var1.pred", "quantile..0.5"), pal="Blues", size=0.2) + tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("Preciptation", "Kriging predictons", "Random Forest predictions"))


## ---- echo=TRUE----------------------------------------------------------------------------
tm_shape(resa) + tm_symbols(col=c("var1.stdev", "rf_sda"), pal="Reds", size=0.2) + tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("Kriging std. dev", "Random Forest 0.159-0.841 range"))


## ---- echo = TRUE--------------------------------------------------------------------------
library(sf)
drumlins <- st_geometry(st_read("drumlins.gpkg"))


## ---- echo = TRUE--------------------------------------------------------------------------
library(spatstat)
(drumlins_ppp <- as.ppp(drumlins))


## ---- echo = TRUE--------------------------------------------------------------------------
bb <- boundingbox(drumlins_ppp)
ch <- convexhull.xy(drumlins_ppp)
rr <- ripras(drumlins_ppp)
drumlins_rr <- ppp(drumlins_ppp$x, drumlins_ppp$y, window=rr)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(drumlins_ppp)
plot(bb, add=TRUE, border="darkgreen", lwd=2, lty=1)
plot(ch, add=TRUE, border="darkred", lwd=2, lty=3)
plot(rr, add=TRUE, border="orange", lwd=2, lty=2)


## ---- echo = TRUE--------------------------------------------------------------------------
qc <- quadratcount(drumlins_ppp)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(drumlins, cex=0.8)
t3 <- cbind(expand.grid(x=attr(qc, "xbreaks")[1:5] + diff(attr(qc, "xbreaks"))[1]/2, y=rev(attr(qc, "ybreaks")[1:5] + diff(attr(qc, "ybreaks"))[1]/2)), qc=c(t(qc)))
text(t3[,1], t3[,2], t3[,3], cex=1.2, font=2, col="darkred")
abline(h=attr(qc, "ybreaks"))
abline(v=attr(qc, "xbreaks"))


## ---- echo = TRUE--------------------------------------------------------------------------
quadrat.test(drumlins_ppp)


## ---- echo = TRUE--------------------------------------------------------------------------
quadrat.test(drumlins_ppp, nx=6)
quadrat.test(drumlins_rr)


## ---- echo = TRUE--------------------------------------------------------------------------
crds <- crds <- st_coordinates(st_sample(st_as_sfc(rr), size=10000, type="regular"))
crds <- list(x=crds[,1], y=crds[,2])
library(raster)
k02 <- as(density(drumlins_rr, sigma=0.2, xy=crds), "RasterLayer")
k04 <- as(density(drumlins_rr, sigma=0.4, xy=crds), "RasterLayer")
k06 <- as(density(drumlins_rr, sigma=0.6, xy=crds), "RasterLayer")
k08 <- as(density(drumlins_rr, sigma=0.8, xy=crds), "RasterLayer")
rB <- brick(k02, k04, k06, k08)
library(stars)
rB_st <- st_as_stars(rB)


## ---- echo=TRUE----------------------------------------------------------------------------
library(tmap)
st_crs(rB_st) <- 32662
st_crs(drumlins) <- 32662
tm_shape(rB_st) + tm_raster(title="Density") + tm_layout(panel.labels=c("0.2", "0.4", "0.6", "0.8")) + tm_shape(drumlins) + tm_symbols(size=0.25, shape=4)


## ---- echo = TRUE--------------------------------------------------------------------------
summary(rB)


## ---- echo = TRUE--------------------------------------------------------------------------
boxplot(rB)


## ---- echo = TRUE--------------------------------------------------------------------------
nns <- nndist(drumlins_rr)
summary(nns)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(ecdf(nns))


## ---- echo = TRUE, eval=FALSE--------------------------------------------------------------
## plot(ecdf(nns), xlim=c(0, 0.5))
## plot(Gest(drumlins_ppp), add=TRUE, lwd=3)


## ---- echo = TRUE--------------------------------------------------------------------------
n <- drumlins_rr$n
set.seed(121122)
ex <- expression(runifpoint(n, win=rr))
res <- envelope(drumlins_rr, Gest, nsim=99, simulate=ex, 
        verbose=FALSE, savefuns=TRUE)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(res, xlim=c(0,0.7))
for(i in 2:100) lines(attr(res, "simfuns")[[1]], attr(res, "simfuns")[[i]], col="grey")
plot(res, add=TRUE, lwd=3, xlim=c(0,0.7))


## ---- echo = TRUE--------------------------------------------------------------------------
clarkevans(drumlins_ppp)
clarkevans(drumlins_rr, correction="none")
clarkevans(drumlins_rr, correction="guard", clipregion=erosion.owin(rr, r=1))


## ---- echo = TRUE, cache=TRUE--------------------------------------------------------------
ex <- expression(rSSI(0.18, n, win=rr))
set.seed(121122)
res <- envelope(drumlins_rr, Gest, nsim=99, simulate=ex, 
                verbose=FALSE, savefuns=TRUE)


## ---- echo=TRUE----------------------------------------------------------------------------
null <- capture.output(plot(res, xlim=c(0,0.7)))
for(i in 2:100) lines(attr(res, "simfuns")[[1]], attr(res, "simfuns")[[i]], col="grey")
null <- capture.output(plot(res, add=TRUE, lwd=3, xlim=c(0,0.7)))


## ---- echo = TRUE, cache=TRUE--------------------------------------------------------------
ex <- expression(runifpoint(n, win=rr))
set.seed(121122)
res <- envelope(drumlins_rr, Kest, nsim=99, simulate=ex, 
                verbose=FALSE, savefuns=TRUE)


## ---- echo=TRUE----------------------------------------------------------------------------
r <- res$r
Lhat <- function(k, r) { (sqrt(k/pi)) - r }
plot(r, Lhat(res$obs, r), type="n", ylab="L(r)", main="CSR simulation", ylim=c(-0.17, 0.1))
for(i in 2:100) lines(r, Lhat(attr(res, "simfuns")[[i]], r), col="grey")
lines(r, Lhat(res$obs, r), lwd=2, col="brown")
lines(r, Lhat(res$lo, r), lwd=2, col="black", lty=2)
lines(r, Lhat(res$hi, r), lwd=2, col="black", lty=2)


## ---- echo = TRUE, cache=TRUE--------------------------------------------------------------
ex <- expression(rSSI(0.18, n, win=rr))
set.seed(121122)
res <- envelope(drumlins_rr, Kest, nsim=99, simulate=ex, 
                verbose=FALSE, savefuns=TRUE)


## ---- echo=TRUE----------------------------------------------------------------------------
r <- res$r
Lhat <- function(k, r) { (sqrt(k/pi)) - r }
plot(r, Lhat(res$obs, r), type="n", ylab="L(r)", main="SSI simulation", ylim=c(-0.17, 0.1))
for(i in 2:100) lines(r, Lhat(attr(res, "simfuns")[[i]], r), col="grey")
lines(r, Lhat(res$obs, r), lwd=2, col="brown")
lines(r, Lhat(res$lo, r), lwd=2, col="black", lty=2)
lines(r, Lhat(res$hi, r), lwd=2, col="black", lty=2)


## ---- echo = TRUE, cache=TRUE--------------------------------------------------------------
ex <- expression(runifpoint(n, win=rr))
set.seed(121122)
res <- envelope(drumlins_rr, Kinhom, nsim=99, simulate=ex, 
                verbose=FALSE, savefuns=TRUE)


## ---- echo=TRUE----------------------------------------------------------------------------
r <- res$r
Lhat <- function(k, r) { (sqrt(k/pi)) - r }
plot(r, Lhat(res$obs, r), type="n", ylab="L(r)", main="CSR simulation", ylim=c(-0.17, 0.1))
for(i in 2:100) lines(r, Lhat(attr(res, "simfuns")[[i]], r), col="grey")
lines(r, Lhat(res$obs, r), lwd=2, col="brown")
lines(r, Lhat(res$lo, r), lwd=2, col="black", lty=2)
lines(r, Lhat(res$hi, r), lwd=2, col="black", lty=2)


## ---- echo = TRUE, cache=TRUE--------------------------------------------------------------
ex <- expression(rSSI(0.18, n, win=rr))
set.seed(121122)
res <- envelope(drumlins_rr, Kinhom, nsim=99, simulate=ex, 
                verbose=FALSE, savefuns=TRUE)


## ---- echo=TRUE----------------------------------------------------------------------------
r <- res$r
Lhat <- function(k, r) { (sqrt(k/pi)) - r }
plot(r, Lhat(res$obs, r), type="n", ylab="L(r)", main="SSI simulation", ylim=c(-0.17, 0.1))
for(i in 2:100) lines(r, Lhat(attr(res, "simfuns")[[i]], r), col="grey")
lines(r, Lhat(res$obs, r), lwd=2, col="brown")
lines(r, Lhat(res$lo, r), lwd=2, col="black", lty=2)
lines(r, Lhat(res$hi, r), lwd=2, col="black", lty=2)


## ---- echo = TRUE--------------------------------------------------------------------------
points <- st_read("cc.gpkg", layer="points")
rivers <- st_geometry(st_read("cc.gpkg", layer="rivers"))
poly <- st_geometry(st_read("cc.gpkg", layer="poly"))


## ---- echo=TRUE----------------------------------------------------------------------------
plot(poly)
plot(rivers, add=TRUE)
plot(st_geometry(points), pch=3:4, add=TRUE)


## ---- echo = TRUE--------------------------------------------------------------------------
points$mark <- factor(points$mark)
points.ppp <- as.ppp(points)
points.ppp$window <- as.owin(poly)
summary(points.ppp)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(split(points.ppp))


## ---- echo = TRUE--------------------------------------------------------------------------
XY <- st_coordinates(st_sample(poly, size=10000, type="regular"))
XY <- list(x=XY[,1], y=XY[,2])
Z <- density(points.ppp, xy=XY)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(Z)


## ---- echo = TRUE--------------------------------------------------------------------------
Z <- density(split(points.ppp), xy=XY)


## ---- echo=TRUE----------------------------------------------------------------------------
plot(Z)


## ---- echo = TRUE--------------------------------------------------------------------------
pCases <- with(Z, eval.im(case/(case + control)))


## ---- echo=TRUE----------------------------------------------------------------------------
plot(pCases)
plot(points.ppp, add=TRUE)


## ----sI, echo = TRUE-----------------------------------------------------------------------
sessionInfo()

