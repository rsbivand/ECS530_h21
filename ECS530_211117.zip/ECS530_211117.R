
## ---- echo=TRUE----------------------------------------------------------------------------
needed <- c("rgeoda", "digest", "igraph", "tmap", "spdep", "spData", "sp", "gstat",
"spatstat.linnet", "spatstat.core", "spatstat.geom", "spatstat.data_2.1-0")


## ---- echo=TRUE----------------------------------------------------------------------------
suppressPackageStartupMessages(library(spatstat))
intenfun <- function(x, y) 200 * x
set.seed(1)
(ihpp <- rpoispp(intenfun, lmax = 200))


## ---- echo=TRUE, out.width='90%', fig.align='center'---------------------------------------
plot(density(ihpp), axes=TRUE)
points(ihpp, col="green2", pch=19)


## ---- echo=TRUE, out.width='90%', fig.align='center'---------------------------------------
opar <- par(mfrow=c(1,2))
plot(envelope(ihpp, Kest, verbose=FALSE), main="Homogeneous")
plot(envelope(ihpp, Kinhom, verbose=FALSE), main="Inhomogeneous")
par(opar)


## ---- echo=TRUE, out.width='90%', fig.align='center'---------------------------------------
library(sf)
sf_ihpp <- subset(st_as_sf(ihpp), label == "point")
#st_as_sf(ihpp) %>% dplyr::filter(label == "point") -> sf_ihpp
#st_as_sf(ihpp) ->.; .[.$label == "point",] -> sf_ihpp
crds <- st_coordinates(sf_ihpp)
sf_ihpp$x <- crds[,1]
sf_ihpp$y <- 100 + 50 * sf_ihpp$x + 20 * rnorm(nrow(sf_ihpp))
plot(sf_ihpp[,"y"], pch=19)


## ---- echo=TRUE, out.width='90%', fig.align='center'---------------------------------------
suppressPackageStartupMessages(library(gstat))
vg0 <- variogram(y ~ 1, sf_ihpp)
vg1 <- variogram(y ~ x, sf_ihpp)
library(ggplot2)
g0 <- ggplot(vg0, aes(x=dist, y=gamma)) + geom_point() + geom_smooth(span=1) + ylim(300, 575) + ggtitle("Trend ignored")
g1 <- ggplot(vg1, aes(x=dist, y=gamma)) + geom_point() + geom_smooth(span=1) + ylim(300, 575) + ggtitle("Trend included")
gridExtra::grid.arrange(g0, g1, ncol=2)


## ---- echo=TRUE, results='hide', message=FALSE---------------------------------------------
suppressPackageStartupMessages(library(spdep))
nb_tri <- tri2nb(crds)


## ---- echo=TRUE----------------------------------------------------------------------------
(nb_soi <- graph2nb(soi.graph(nb_tri, crds), sym=TRUE))


## ---- echo=TRUE, out.width='90%', fig.align='center'---------------------------------------
plot(nb_soi, crds)


## ---- echo=TRUE----------------------------------------------------------------------------
comps <- n.comp.nb(nb_soi)
sf_ihpp$comps <- comps$comp.id
comps$nc


## ---- echo=TRUE, warning=FALSE, message=FALSE----------------------------------------------
lwB <- nb2listw(nb_soi, style="B")
out <- broom::tidy(moran.test(sf_ihpp$y, listw=lwB, randomisation=FALSE, alternative="two.sided"))[1:5]
names(out)[1:3] <- c("Moran's I", "Expectation", "Variance"); out


## ---- echo=TRUE----------------------------------------------------------------------------
lm_obj <- lm(y ~ x, data=sf_ihpp)
out <- broom::tidy(lm.morantest(lm_obj, listw=lwB, alternative="two.sided"))[1:5]
names(out)[1:3] <- c("Moran's I", "Expectation", "Variance"); out


## ---- echo=TRUE----------------------------------------------------------------------------
lmor0 <- localmoran(sf_ihpp$y, listw=lwB, alternative="two.sided")
lmor1 <- as.data.frame(localmoran.sad(lm_obj, nb=nb_soi, style="B", alternative="two.sided"))
sf_ihpp$z_value <- lmor0[,4]
sf_ihpp$z_lmor1_N <- lmor1[,2]
sf_ihpp$z_lmor1_SAD <- lmor1[,4]


## ---- echo=TRUE, warning=FALSE, out.width='90%', fig.align='center', width=7, height=4-----
suppressPackageStartupMessages(library(tmap))
tm_shape(sf_ihpp) + tm_symbols(col=c("z_value", "z_lmor1_N", "z_lmor1_SAD"), midpoint=0) + tm_facets(free.scales=FALSE, nrow=1) + tm_layout(panel.labels=c("No trend", "Trend, normal", "Trend, SAD"))


## ---- echo=TRUE----------------------------------------------------------------------------
library(sf)
nc <- st_read(system.file("shapes/sids.shp", package="spData")[1], quiet=TRUE)
st_crs(nc) <- "+proj=longlat +datum=NAD27"
row.names(nc) <- as.character(nc$FIPSNO)
head(nc)


## ---- echo=TRUE, warning=FALSE-------------------------------------------------------------
library(spdep)
gal_file <- system.file("weights/ncCR85.gal", package="spData")[1]
ncCR85 <- read.gal(gal_file, region.id=nc$FIPSNO)
ncCR85


## ---- echo=TRUE, warning=TRUE, out.width='90%', fig.align='center', width=7, height=4------
plot(st_geometry(nc), border="grey")
plot(ncCR85, st_centroid(st_geometry(nc), of_largest_polygon), add=TRUE, col="blue")


## ---- echo=TRUE----------------------------------------------------------------------------
set.seed(1)
nc$rand <- rnorm(nrow(nc))
lw <- nb2listw(ncCR85, style="B")
moran.test(nc$rand, listw=lw, alternative="two.sided")


## ---- echo=TRUE----------------------------------------------------------------------------
nc$LM <- as.numeric(interaction(nc$L_id, nc$M_id))
alpha <- 1
beta <- 0.5
sigma <- 2
nc$trend <- alpha + beta*nc$LM + sigma*nc$rand
moran.test(nc$trend, listw=lw, alternative="two.sided")


## ---- echo=TRUE----------------------------------------------------------------------------
lm.morantest(lm(trend ~ LM, nc), listw=lw, alternative="two.sided")


## ---- echo=TRUE----------------------------------------------------------------------------
aggLM <- aggregate(nc[,"LM"], list(nc$LM), head, n=1)
(aggnb <- poly2nb(aggLM))


## ---- echo=TRUE----------------------------------------------------------------------------
set.seed(1)
LMrand <- rnorm(nrow(aggLM))


## ---- echo=TRUE----------------------------------------------------------------------------
moran.test(LMrand, nb2listw(aggnb, style="B"))


## ---- echo=TRUE----------------------------------------------------------------------------
nc$LMrand <- LMrand[match(nc$LM, aggLM$LM)]
plot(nc[,"LMrand"])


## ---- echo=TRUE----------------------------------------------------------------------------
moran.test(nc$LMrand, listw=lw, alternative="two.sided")


## ------------------------------------------------------------------------------------------
data(pol_pres15, package="spDataLarge")
pol_pres15 |> 
    subset(select=c(TERYT, name, types)) |> 
    head()


## ----plotpolpres15-------------------------------------------------------------------------
library(tmap)
tm_shape(pol_pres15) + tm_fill("types")


## ------------------------------------------------------------------------------------------
library(spdep)


## ------------------------------------------------------------------------------------------
args(poly2nb)


## ------------------------------------------------------------------------------------------
system.time(pol_pres15 |> poly2nb(queen=TRUE) -> nb_q)


## ------------------------------------------------------------------------------------------
nb_q


## ------------------------------------------------------------------------------------------
(nb_q |> n.comp.nb())$nc


## ------------------------------------------------------------------------------------------
library(Matrix)
nb_q |> 
    nb2listw(style="B") |> 
    as("CsparseMatrix") -> smat
library(igraph)
(smat |> 
        graph.adjacency() -> g1) |> 
    count_components()


## ------------------------------------------------------------------------------------------
tf <- tempfile(fileext=".gal")
write.nb.gal(nb_q, tf)


## ------------------------------------------------------------------------------------------
pol_pres15 |> 
    st_geometry() |> 
    st_centroid(of_largest_polygon=TRUE) -> coords 
(coords |> tri2nb() -> nb_tri)


## ------------------------------------------------------------------------------------------
nb_tri |> 
    nbdists(coords) |> 
    unlist() |> 
    summary()


## ------------------------------------------------------------------------------------------
(nb_tri |> n.comp.nb())$nc


## ------------------------------------------------------------------------------------------
(nb_tri |> 
        soi.graph(coords) |> 
        graph2nb() -> nb_soi)


## ------------------------------------------------------------------------------------------
(nb_soi |> n.comp.nb() -> n_comp)$nc


## ------------------------------------------------------------------------------------------
table(n_comp$comp.id)


## ----plotnbdiff----------------------------------------------------------------------------
opar <- par(mar=c(0,0,0,0)+0.5)
pol_pres15 |> 
    st_geometry() |> 
    plot(border="grey", lwd=0.5)
nb_soi |> 
    plot(coords=coords, add=TRUE, points=FALSE, lwd=0.5)
nb_tri |> 
    diffnb(nb_soi) |> 
    plot(coords=coords, col="orange", add=TRUE, points=FALSE, lwd=0.5)
par(opar)


## ------------------------------------------------------------------------------------------
coords |> 
    knearneigh(k=1) |> 
    knn2nb() |> 
    nbdists(coords) |> 
    unlist() |> 
    summary()


## ------------------------------------------------------------------------------------------
system.time(coords |> dnearneigh(0, 18000) -> nb_d18)
system.time(coords |> dnearneigh(0, 18000, use_kd_tree=FALSE) -> nb_d18a)
all.equal(nb_d18, nb_d18a, check.attributes=FALSE)
nb_d18


## ------------------------------------------------------------------------------------------
(nb_d18 |> n.comp.nb() -> n_comp)$nc

## ------------------------------------------------------------------------------------------
table(n_comp$comp.id)


## ------------------------------------------------------------------------------------------
(coords |> dnearneigh(0, 18300) -> nb_d183)

## ------------------------------------------------------------------------------------------
(nb_d183 |> n.comp.nb())$nc


## ------------------------------------------------------------------------------------------
(coords |> dnearneigh(0, 16000) -> nb_d16)


## ------------------------------------------------------------------------------------------
(coords |> knearneigh(k=6) -> knn_k6) |> knn2nb()


## ------------------------------------------------------------------------------------------
(knn_k6 |> knn2nb(sym=TRUE) -> nb_k6s)


## ------------------------------------------------------------------------------------------
(nb_k6s |> n.comp.nb())$nc


## ------------------------------------------------------------------------------------------
args(nb2listw)


## ------------------------------------------------------------------------------------------
args(spweights.constants)


## ------------------------------------------------------------------------------------------
(nb_q |> 
        nb2listw(style="B") -> lw_q_B) |> 
    spweights.constants() |> 
    data.frame() |> 
    subset(select=c(n, S0, S1, S2))


## ------------------------------------------------------------------------------------------
(nb_q |> 
        nb2listw(style="W") -> lw_q_W) |> 
    spweights.constants() |> 
    data.frame() |> 
    subset(select=c(n, S0, S1, S2))


## ------------------------------------------------------------------------------------------
nb_d183 |> 
    nbdists(coords) |> 
    lapply(\(x) 1/(x/1000)) -> gwts
(nb_d183 |> nb2listw(glist=gwts, style="B") -> lw_d183_idw_B) |> 
    spweights.constants() |> 
    data.frame() |> 
    subset(select=c(n, S0, S1, S2))


## ------------------------------------------------------------------------------------------
try(nb_d16 |> nb2listw(style="B") -> lw_d16_B)


## ------------------------------------------------------------------------------------------
nb_d16 |> 
    nb2listw(style="B", zero.policy=TRUE) |> 
    spweights.constants(zero.policy=TRUE) |> 
    data.frame() |> 
    subset(select=c(n, S0, S1, S2))


## ------------------------------------------------------------------------------------------
nb_q


## ------------------------------------------------------------------------------------------
(nb_q |> nblag(2) -> nb_q2)[[2]]


## ------------------------------------------------------------------------------------------
nblag_cumul(nb_q2)


## ------------------------------------------------------------------------------------------
union.nb(nb_q2[[2]], nb_q2[[1]])


## ------------------------------------------------------------------------------------------
diameter(g1)


## ------------------------------------------------------------------------------------------
g1 |> shortest.paths() -> sps
(sps |> apply(2, max) -> spmax) |> max()


## ------------------------------------------------------------------------------------------
mr <- which.max(spmax)
pol_pres15$name0[mr]


## ---- echo=FALSE---------------------------------------------------------------------------
pol_pres15$sps1 <- sps[,mr]
tm1 <- tm_shape(pol_pres15) + tm_fill("sps1", title="Shortest path\ncount")


## ---- echo=FALSE---------------------------------------------------------------------------
coords[mr] |> 
    st_distance(coords) |> 
    c() |> 
    (\(x) x/1000)() |> 
    units::set_units(NULL) -> pol_pres15$dist_52
library(ggplot2)
g1 <- ggplot(pol_pres15, aes(x=sps1, y=dist_52)) + geom_point() + xlab("shortest path count") +  ylab("km distance")


## ----shortestpath--------------------------------------------------------------------------
gridExtra::grid.arrange(tmap_grob(tm1), g1, nrow=1)


## ---- eval=FALSE---------------------------------------------------------------------------
## library(spdep)
## t0 <- system.time(nb_subset <- poly2nb(df_tracts, queen=TRUE, row.names=map10$GEOID))
## saveRDS(nb_subset, file="nb_subset.rds")
## #   user  system elapsed
## # 24.233   0.129  24.417


## ---- eval=TRUE----------------------------------------------------------------------------
library(spdep)
(nb_subset <- readRDS("nb_subset.rds"))


## ------------------------------------------------------------------------------------------
library(sf)


## ------------------------------------------------------------------------------------------
data(pol_pres15, package="spDataLarge")
pol_pres15 |> 
    subset(select=c(TERYT, name, types)) |> 
    head()


## ------------------------------------------------------------------------------------------
library(spdep)
pol_pres15 |> poly2nb(queen=TRUE) -> nb_q
nb_q |> nb2listw(style="B") -> lw_q_B
nb_q |> nb2listw(style="W") -> lw_q_W


## ------------------------------------------------------------------------------------------
pol_pres15 |> st_geometry() |> st_centroid(of_largest_polygon=TRUE) -> coords 
coords |> dnearneigh(0, 18300) -> nb_d183
nb_d183 |> nbdists(coords) |> lapply(\(x) 1/(x/1000)) -> gwts
nb_d183 |> nb2listw(glist=gwts, style="B") -> lw_d183_idw_B


## ------------------------------------------------------------------------------------------
args(joincount.test)


## ------------------------------------------------------------------------------------------
(pol_pres15 |> 
        st_drop_geometry() |> 
        subset(select=types, drop=TRUE) -> Types) |> 
    table()


## ------------------------------------------------------------------------------------------
Types |> joincount.multi(listw=lw_q_B)


## ------------------------------------------------------------------------------------------
Types |> joincount.multi(listw=lw_d183_idw_B)


## ------------------------------------------------------------------------------------------
args(moran.test)


## ------------------------------------------------------------------------------------------
glance_htest <- function(ht) c(ht$estimate, 
    "Std deviate"=unname(ht$statistic), 
    "p.value"=unname(ht$p.value))
(pol_pres15 |> 
        st_drop_geometry() |> 
        subset(select=I_turnout, drop=TRUE) -> z) |> 
    moran.test(listw=lw_q_B, randomisation=FALSE) |> 
    glance_htest()


## ------------------------------------------------------------------------------------------
lm(I_turnout ~ 1, pol_pres15) |> 
    lm.morantest(listw=lw_q_B) |> 
    glance_htest()


## ------------------------------------------------------------------------------------------
(z |> 
    moran.test(listw=lw_q_B) -> mtr) |> 
    glance_htest()


## ------------------------------------------------------------------------------------------
set.seed(1)
z |> 
    moran.mc(listw=lw_q_B, nsim=999, return_boot = TRUE) -> mmc


## ------------------------------------------------------------------------------------------
c("Permutation bootstrap"=var(mmc$t), 
  "Analytical randomisation"=unname(mtr$estimate[3]))


## ------------------------------------------------------------------------------------------
df_tracts <- st_read("df_tracts.gpkg")


## ------------------------------------------------------------------------------------------
(nb_subset <- readRDS("nb_subset.rds"))


## ------------------------------------------------------------------------------------------
nc_nb_subset <- n.comp.nb(nb_subset)
nc_nb_subset$nc
table(table(nc_nb_subset$comp.id))


## ------------------------------------------------------------------------------------------
set.ZeroPolicyOption(TRUE)
lw <- nb2listw(nb_subset, style="W")


## ------------------------------------------------------------------------------------------
system.time(mt_med_inc_cv <- moran.test(df_tracts$med_inc_cv, lw, alternative="two.sided"))


## ------------------------------------------------------------------------------------------
mt_med_inc_cv


## ------------------------------------------------------------------------------------------
form <- log(med_inc_cv) ~ log1p(vacancy_rate) + log1p(old_rate) + log1p(black_rate) + log1p(hisp_rate) + log1p(group_pop) + log1p(dens)


## ------------------------------------------------------------------------------------------
lm_mod <- lm(form, data=df_tracts)
summary(lm_mod)


## ------------------------------------------------------------------------------------------
lm.morantest(lm_mod, lw)


## ----moranplot-----------------------------------------------------------------------------
z |> moran.plot(listw=lw_q_W, labels=pol_pres15$TERYT, cex=1, pch=".", xlab="I round turnout", ylab="lagged turnout") -> infl_W


## ----moranhat------------------------------------------------------------------------------
pol_pres15$hat_value <- infl_W$hat
library(tmap)
tm_shape(pol_pres15) + tm_fill("hat_value")


## ------------------------------------------------------------------------------------------
z |> 
    localmoran(listw=lw_q_W, conditional=FALSE, alternative="two.sided") -> locm


## ------------------------------------------------------------------------------------------
all.equal(sum(locm[,1])/Szero(lw_q_W), unname(moran.test(z, lw_q_W)$estimate[1]))


## ------------------------------------------------------------------------------------------
pva <- \(pv) cbind("none"=pv, "bonferroni"=p.adjust(pv, "bonferroni"), "fdr"=p.adjust(pv, "fdr"), "BY"=p.adjust(pv, "BY"))
locm |> 
    subset(select="Pr(z != E(Ii))", drop=TRUE) |> 
    pva() -> pvsp
f <- \(x) sum(x < 0.05)
apply(pvsp, 2, f)


## ------------------------------------------------------------------------------------------
library(parallel)
set.coresOption(ifelse(detectCores() == 1, 1, detectCores()-1L))
system.time(z |> 
        localmoran_perm(listw=lw_q_W, nsim=499, alternative="two.sided", iseed=1) -> locm_p)


## ------------------------------------------------------------------------------------------
locm_p |> 
    subset(select="Pr(z != E(Ii))", drop=TRUE) |> 
    pva() -> pvsp
apply(pvsp, 2, f)


## ------------------------------------------------------------------------------------------
brks <- qnorm(c(0, 0.00001, 0.0001, 0.001, 0.01, 0.025, 0.5, 0.975, 0.99, 0.999, 0.9999, 0.99999, 1))
(locm_p |> 
        subset(select=Z.Ii, drop=TRUE) |> 
        cut(brks) |> 
        table()-> tab)


## ------------------------------------------------------------------------------------------
sum(tab[c(1:5, 8:12)])


## ------------------------------------------------------------------------------------------
sum(tab[c(1, 12)])


## ------------------------------------------------------------------------------------------
z |> 
    localmoran(listw=lw_q_W, conditional=TRUE, alternative="two.sided") -> locm_c


## ------------------------------------------------------------------------------------------
locm_c |> 
    subset(select="Pr(z != E(Ii))", drop=TRUE) |> 
    pva() -> pvsp
apply(pvsp, 2, f)


## ----localmoranZ---------------------------------------------------------------------------
pol_pres15$locm_Z <- locm[, "Z.Ii"]
pol_pres15$locm_c_Z <- locm_c[, "Z.Ii"]
pol_pres15$locm_p_Z <- locm_p[, "Z.Ii"]
tm_shape(pol_pres15) + tm_fill(c("locm_Z", "locm_c_Z", "locm_p_Z"), breaks=brks, midpoint=0, title="Standard deviates of\nLocal Moran's I") + tm_facets(free.scales=FALSE, ncol=2) + tm_layout(panel.labels=c("Analytical total", "Analytical conditional", "Conditional permutation"))


## ------------------------------------------------------------------------------------------
q_mean <- attr(locm, "quadr")$mean
pol_pres15$hs_ac_q <- pol_pres15$hs_cp_q <- pol_pres15$hs_an_q <- q_mean
is.na(pol_pres15$hs_an_q) <- !(pol_pres15$locm_Z < brks[6] | pol_pres15$locm_Z > brks[8])
is.na(pol_pres15$hs_cp_q) <- !(pol_pres15$locm_p_Z < brks[2] | pol_pres15$locm_p_Z > brks[12])
is.na(pol_pres15$hs_ac_q) <- !(pol_pres15$locm_c_Z < brks[2] | pol_pres15$locm_c_Z > brks[12])


## ----Iihotspots----------------------------------------------------------------------------
tm_shape(pol_pres15) + tm_fill(c("hs_an_q", "hs_ac_q", "hs_cp_q"), colorNA="grey95", textNA="Not significant", title="Turnout hotspot status\nLocal Moran's I") + tm_facets(free.scales=FALSE, ncol=2) + tm_layout(panel.labels=c("Unadjusted analytical total", "Bonferroni analytical cond.", "Cond. perm. with Bonferroni"))


## ------------------------------------------------------------------------------------------
system.time(z |> 
        localG(lw_q_W) -> locG)


## ------------------------------------------------------------------------------------------
system.time(z |> 
        localG_perm(lw_q_W, nsim=499, iseed=1) -> locG_p)


## ------------------------------------------------------------------------------------------
locG |> 
    c() |> 
    abs() |> 
    pnorm(lower.tail = FALSE) |> 
    (\(x) x*2)() |> 
    pva() -> pvsp
apply(pvsp, 2, f)


## ----localZvalues--------------------------------------------------------------------------
library(ggplot2)
p1 <- ggplot(data.frame(Zi=locm_c[,4], Zi_perm=locm_p[,4])) + geom_point(aes(x=Zi, y=Zi_perm), alpha=0.2) + xlab("Analytical conditional") + ylab("Permutation conditional") + coord_fixed() + ggtitle("Local Moran's I")
p2 <- ggplot(data.frame(Zi=c(locG), Zi_perm=c(locG_p))) + geom_point(aes(x=Zi, y=Zi_perm), alpha=0.2) + xlab("Analytical conditional") + ylab("Permutation conditional") + coord_fixed() + ggtitle("Local G")
gridExtra::grid.arrange(p1, p2, nrow=1)


## ------------------------------------------------------------------------------------------
pol_pres15$locG_Z <- c(locG)
pol_pres15$hs_G <- cut(c(locG), c(-Inf, brks[2], brks[12], Inf), labels=c("Low", "Not significant", "High"))
table(pol_pres15$hs_G)


## ----localG--------------------------------------------------------------------------------
m1 <- tm_shape(pol_pres15) + tm_fill(c("locG_Z"), midpoint=0, title="Standard\ndeviate")
m2 <- tm_shape(pol_pres15) + tm_fill(c("hs_G"), title="Bonferroni\nhotspot status")
tmap_arrange(m1, m2, nrow=1)


## ------------------------------------------------------------------------------------------
library(rgeoda)
system.time(Geoda_w <- queen_weights(pol_pres15))
summary(Geoda_w)
system.time(lisa <- local_moran(Geoda_w, pol_pres15["I_turnout"], 
    cpu_threads=ifelse(parallel::detectCores() == 1, 1, parallel::detectCores()-1L), permutations=499, seed=1))
all.equal(card(nb_q), lisa_num_nbrs(lisa), check.attributes=FALSE)
all.equal(lisa_values(lisa), localmoran(pol_pres15$I_turnout, listw=lw_q_W, mlvar=FALSE)[,1], check.attributes=FALSE)


## ----sI, echo = TRUE-----------------------------------------------------------------------
sessionInfo()

